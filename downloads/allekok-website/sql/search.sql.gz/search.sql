-- phpMyAdmin SQL Dump
-- version 4.4.14.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 27, 2020 at 04:10 AM
-- Server version: 5.6.36
-- PHP Version: 5.3.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `allekoki_search`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE IF NOT EXISTS `books` (
  `id` int(10) NOT NULL,
  `book` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `book_desc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `poet_id` int(10) NOT NULL,
  `book_id` int(10) NOT NULL,
  `rbook` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rtakh` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `len` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `poems`
--

CREATE TABLE IF NOT EXISTS `poems` (
  `id` int(10) NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `hdesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `poet_id` int(10) NOT NULL,
  `book_id` int(10) NOT NULL,
  `poem_id` int(10) NOT NULL,
  `poem` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `poem_true` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rname` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rbook` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `rtakh` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Cipi` float NOT NULL DEFAULT '0' COMMENT 'Cipi = C/imp',
  `len` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `poets`
--

CREATE TABLE IF NOT EXISTS `poets` (
  `id` int(5) NOT NULL,
  `name` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `takh` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profname` varchar(400) COLLATE utf8mb4_unicode_ci NOT NULL,
  `hdesc` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `rtakh` varchar(300) COLLATE utf8mb4_unicode_ci NOT NULL,
  `len` int(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `poems`
--
ALTER TABLE `poems`
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexes for table `poets`
--
ALTER TABLE `poets`
  ADD UNIQUE KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `poems`
--
ALTER TABLE `poems`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
